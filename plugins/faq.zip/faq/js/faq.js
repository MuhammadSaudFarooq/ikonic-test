var $ = jQuery.noConflict();
var ajax_url = url.ajaxurl;
var site_url = url.siteurl;

$(document).ready(function () {
});